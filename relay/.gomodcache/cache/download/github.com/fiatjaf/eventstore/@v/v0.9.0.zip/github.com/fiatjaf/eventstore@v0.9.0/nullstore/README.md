`nullstore` is an eventstore that doesn't actually do anything.
It doesn't store anything, it doesn't return anything.
