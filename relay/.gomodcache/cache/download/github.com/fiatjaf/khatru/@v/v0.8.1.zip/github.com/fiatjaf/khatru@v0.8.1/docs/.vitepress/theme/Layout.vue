<script setup>
import DefaultTheme from 'vitepress/theme'
const {Layout} = DefaultTheme
</script>
<template>
  <Layout>
    <template #layout-bottom>
      <div class="khatru-layout-bottom">~</div>
    </template>
  </Layout>
</template>
