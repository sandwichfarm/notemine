package pbytes
