//go:build !debug

package nostr

func debugLogf(str string, args ...any) {
}
