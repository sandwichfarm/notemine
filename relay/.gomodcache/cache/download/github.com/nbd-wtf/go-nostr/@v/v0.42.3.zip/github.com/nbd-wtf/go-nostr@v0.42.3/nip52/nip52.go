package nip52

const DateFormat = "2006-01-02"
