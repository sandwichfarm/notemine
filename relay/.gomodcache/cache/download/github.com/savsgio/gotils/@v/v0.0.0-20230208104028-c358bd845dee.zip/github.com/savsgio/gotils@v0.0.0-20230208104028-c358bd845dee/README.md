# gotils

[![Test status](https://github.com/savsgio/gotils/actions/workflows/test.yml/badge.svg?branch=master)](https://github.com/savsgio/gotils/actions?workflow=test)
[![Go Report Card](https://goreportcard.com/badge/github.com/savsgio/gotils)](https://goreportcard.com/report/github.com/savsgio/gotils)
[![GoDev](https://img.shields.io/badge/go.dev-reference-007d9c?logo=go&logoColor=white)](https://pkg.go.dev/github.com/savsgio/gotils)

Golang utlities to make your life easier :wink:
