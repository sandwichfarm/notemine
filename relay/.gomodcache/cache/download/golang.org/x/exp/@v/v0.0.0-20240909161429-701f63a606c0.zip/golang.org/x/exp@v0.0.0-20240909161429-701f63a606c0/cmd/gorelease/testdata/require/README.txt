This directory contain tests that assert gorelease behavior when module
requirements (and require statements in the go.mod) have changed.